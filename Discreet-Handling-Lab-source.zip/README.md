# Discreet Handling Lab

Dashboard: https://zero-district-handling-lab.artfulden1.chatgpt.site/

Run node build.mjs, then node scripts/validate-artifact.mjs. Hosting requires R2 BUCKET binding. Credentials excluded.
