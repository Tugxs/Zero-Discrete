const reply=(d,s=200)=>new Response(JSON.stringify(d),{status:s,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}});
export default {async fetch(req,env){try{
 const u=new URL(req.url);if(u.pathname==='/')return new Response(HTML,{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'}});
 if(!env.BUCKET)return reply({error:'Storage not connected'},503);
 if(req.method==='POST'&&req.headers.get('Origin')&&req.headers.get('Origin')!==u.origin)return reply({error:'Origin rejected'},403);
 if(u.pathname==='/api/schema')return reply(SCHEMA);
 if(u.pathname==='/api/profile'){
  const o=await env.BUCKET.get('revuelto-profile.json');const current=o?await o.json():{revision:0,values:SCHEMA.baseline};current.values={...SCHEMA.baseline,...current.values};if(req.method==='GET')return reply(current);
  if(req.method!=='POST')return reply({error:'Method not allowed'},405);const raw=await req.text();if(raw.length>24000)return reply({error:'Request too large'},413);
  const d=JSON.parse(raw);if(d.revision!==current.revision)return reply({error:'تغيّرت الإعدادات من جهاز آخر. حدّث الصفحة قبل الحفظ.'},409);
  let values={};for(const f of SCHEMA.fields){const n=d.values?.[f.key];if(typeof n!=='number'||!Number.isFinite(n)||n<f.min||n>f.max)return reply({error:'قيمة غير مناسبة: '+f.name},400);values[f.key]=n}
  const next={revision:Date.now(),values};const saved=await env.BUCKET.put('revuelto-profile.json',JSON.stringify(next),{onlyIf:o?{etagMatches:o.etag}:{etagDoesNotMatch:'*'}});if(!saved)return reply({error:'تعارض حفظ. حدّث الصفحة.'},409);return reply(next);
 }
 if(u.pathname==='/api/state'){const o=await env.BUCKET.get('telemetry.json');const t=o?await o.json():{seen:0};return reply({connected:Date.now()-t.seen<10000,telemetry:t})}
 if(u.pathname==='/api/telemetry'&&req.method==='POST'){const d=await req.json();await env.BUCKET.put('telemetry.json',JSON.stringify({seen:Date.now(),speed:Number.isFinite(d.speed)?d.speed:0,gear:d.gear,ready:d.ready===true,physical:d.physical===true}));return reply({ok:true})}
 return reply({error:'Not found'},404);
 }catch{return reply({error:'Request could not be processed'},400)}}};
